"""
CrushSim AI — Motor de Simulación (Servicio)
Bond + Whiten + OPEX referencial Chile
"""
from typing import List, Dict, Optional, Any
import math

# ── BASE DE DATOS DE ROCAS ────────────────────────────────────────────────────
ROCK_DB: Dict[str, Dict] = {
    "granito":  {"wi": 15.5, "ab": 0.28, "den": 2.70, "name": "Granito"},
    "caliza":   {"wi": 11.2, "ab": 0.12, "den": 2.60, "name": "Caliza"},
    "cobre":    {"wi": 14.0, "ab": 0.22, "den": 2.75, "name": "Mineral de Cobre"},
    "basalto":  {"wi": 17.0, "ab": 0.35, "den": 2.90, "name": "Basalto"},
    "cuarcita": {"wi": 19.5, "ab": 0.45, "den": 2.65, "name": "Cuarcita"},
    "arenisca": {"wi":  9.5, "ab": 0.08, "den": 2.30, "name": "Arenisca"},
    "porfido":  {"wi": 16.0, "ab": 0.30, "den": 2.72, "name": "Pórfido Cuprífero"},
}

# ── COSTOS REFERENCIALES CHILE 2024-2025 ─────────────────────────────────────
COST_DB = {
    "fuel_usd_l":      1.15,
    "electric_usd_kwh": 0.12,
    "operator_usd_h":  18.0,
    "mechanic_usd_h":  35.0,
    "hours_per_year":  6000,
    "price_ton_usd":   8.0,   # precio árido referencial
    "wear_usd_t": {
        "granito":  {"jaw": 0.18, "cone": 0.22, "screen": 0.06},
        "caliza":   {"jaw": 0.08, "cone": 0.10, "screen": 0.03},
        "cobre":    {"jaw": 0.15, "cone": 0.18, "screen": 0.05},
        "basalto":  {"jaw": 0.22, "cone": 0.28, "screen": 0.07},
        "cuarcita": {"jaw": 0.30, "cone": 0.38, "screen": 0.09},
        "arenisca": {"jaw": 0.06, "cone": 0.07, "screen": 0.02},
        "porfido":  {"jaw": 0.20, "cone": 0.25, "screen": 0.07},
    },
    "maint_pct": {"jaw": 0.08, "cone": 0.10, "screen": 0.05, "scalper": 0.04},
}


# ── INTERPOLACIÓN ─────────────────────────────────────────────────────────────
def lerp(xs: List[float], ys: List[float], x: float) -> float:
    if not xs or not ys or len(xs) < 2:
        return ys[0] if ys else 0.0
    if x <= xs[0]:
        return ys[0]
    if x >= xs[-1]:
        return ys[-1]
    for i in range(len(xs) - 1):
        if xs[i] <= x <= xs[i + 1]:
            t = (x - xs[i]) / (xs[i + 1] - xs[i])
            return ys[i] + t * (ys[i + 1] - ys[i])
    return ys[-1]


# ── MOTOR PRINCIPAL ───────────────────────────────────────────────────────────
def simulate(
    nodes: List[Dict],
    tph: float,
    f80: float,
    p80_target: float,
    rock_type: str,
    humidity: int,
    circuit: str,
    hours_per_year: int = 6000,
) -> Dict[str, Any]:

    rock = ROCK_DB.get(rock_type, ROCK_DB["granito"])
    node_results: Dict[str, Dict] = {}
    current_f80 = f80
    flow_order = ["scalper", "jaw", "cone", "screen"]
    sorted_nodes = sorted(nodes, key=lambda n: flow_order.index(n.get("type", "jaw"))
                          if n.get("type") in flow_order else 99)

    total_energy_kwh_per_ton = 0.0

    for node in sorted_nodes:
        eq = node.get("equipment", {})
        specs = eq.get("specs", {})
        curves = eq.get("curves", {})
        node_type = node.get("type", "")

        if node_type in ("jaw", "cone"):
            css_range = specs.get("cssRange", [10, 200])
            factor = 0.18 if node_type == "jaw" else 0.14
            css_opt = max(css_range[0], min(css_range[1], p80_target * factor))

            # Capacidad e interpolación de curvas
            css_curve = curves.get("css", [css_opt])
            tph_curve  = curves.get("tph", [tph])
            p80_curve  = curves.get("p80factor", [3.5])
            cap_curve = lerp(css_curve, tph_curve, css_opt)
            p80_factor = lerp(css_curve, p80_curve, css_opt)
            p80_out = css_opt * p80_factor

            # Bond (kWh/t)
            try:
                energy = max(0.0, 10 * rock["wi"] * (
                    1 / math.sqrt(max(p80_out, 0.1)) - 1 / math.sqrt(max(current_f80, 0.1))
                ))
            except (ValueError, ZeroDivisionError):
                energy = 0.0

            total_energy_kwh_per_ton += energy
            utilization = min(100.0, (tph / max(cap_curve, 0.1)) * 100)

            node_results[node["id"]] = {
                "css_mm":       round(css_opt, 1),
                "cap_nominal":  round(cap_curve, 0),
                "cap_real":     round(min(tph, cap_curve), 0),
                "p80_in_mm":    round(current_f80, 1),
                "p80_out_mm":   round(p80_out, 1),
                "energy_kwh_t": round(energy, 3),
                "energy_kw_total": round(energy * tph, 1),
                "utilization_pct": round(utilization, 1),
                "ratio_reduction": round(current_f80 / max(p80_out, 0.1), 2),
                "status": "overload" if utilization > 95 else ("ok" if utilization > 60 else "underload"),
            }
            current_f80 = p80_out

        elif node_type in ("screen", "scalper"):
            aperture = p80_target * 0.9
            ap_curve  = curves.get("apertures", [10, 20, 40, 80])
            eff_curve = curves.get("efficiency", [90, 88, 86, 84])
            base_eff = lerp(ap_curve, eff_curve, aperture) / 100
            hum_penalty = humidity * 0.015
            eff_real = max(0.70, base_eff - hum_penalty)
            oversize = tph * (1 - eff_real) * 0.40
            circ_load = (oversize / max(tph, 0.1)) * 100

            node_results[node["id"]] = {
                "aperture_mm":   round(aperture, 1),
                "efficiency_pct": round(eff_real * 100, 1),
                "oversize_tph":  round(oversize, 1),
                "circ_load_pct": round(circ_load, 1),
                "decks":         specs.get("decks", 2),
                "screen_area_m2": (specs.get("screenArea") or [0, 0]),
                "status": "overload" if circ_load > 35 else ("warn" if circ_load > 20 else "ok"),
            }

    # Resultados globales
    last_cone   = next((n for n in reversed(sorted_nodes) if n["type"] == "cone"), None)
    last_screen = next((n for n in reversed(sorted_nodes) if n["type"] == "screen"), None)
    final_p80   = node_results[last_cone["id"]]["p80_out_mm"] if last_cone else current_f80
    final_cc    = node_results[last_screen["id"]]["circ_load_pct"] if last_screen else 0.0

    p80_gap    = abs(final_p80 - p80_target) / max(p80_target, 0.1)
    eff_score  = max(0, min(100, 100 - final_cc * 0.7 - p80_gap * 60 - rock["ab"] * 15))
    bottlenecks = [
        n.get("equipment", {}).get("model", n.get("type", "?"))
        for n in sorted_nodes
        if node_results.get(n["id"], {}).get("status") == "overload"
    ]

    # OPEX
    opex = _calc_opex(sorted_nodes, node_results, tph, rock_type,
                      total_energy_kwh_per_ton, hours_per_year)

    return {
        "node_results":    node_results,
        "final_p80_mm":    round(final_p80, 1),
        "circ_load_pct":   round(final_cc, 1),
        "eff_score":       round(eff_score, 1),
        "bottlenecks":     bottlenecks,
        "rock":            rock,
        "tph":             tph,
        "p80_target_mm":   p80_target,
        "opex":            opex,
    }


# ── OPEX ──────────────────────────────────────────────────────────────────────
def _calc_opex(
    nodes: List[Dict],
    node_results: Dict,
    tph: float,
    rock_type: str,
    energy_kwh_t: float,
    hours_year: int,
) -> Dict[str, float]:

    wear = COST_DB["wear_usd_t"].get(rock_type, COST_DB["wear_usd_t"]["granito"])
    total_wear = 0.0
    total_maint_yr = 0.0
    total_capex = 0.0

    for node in nodes:
        eq = node.get("equipment", {})
        t = node.get("type", "")
        capex_ref = eq.get("capex_usd", 600_000)
        total_capex += capex_ref
        maint_pct = COST_DB["maint_pct"].get(t, 0.07)
        total_maint_yr += capex_ref * maint_pct
        w = wear.get("jaw" if t == "jaw" else "cone" if t == "cone" else "screen", 0.10)
        total_wear += w

    # Costos por tonelada
    energy_cost_t = energy_kwh_t * COST_DB["electric_usd_kwh"]
    labor_cost_t  = (COST_DB["operator_usd_h"] * 1.5) / max(tph, 1)
    maint_cost_t  = total_maint_yr / max(hours_year * tph, 1)
    wear_cost_t   = total_wear
    total_cost_t  = energy_cost_t + labor_cost_t + maint_cost_t + wear_cost_t

    ton_year       = tph * hours_year
    revenue_yr     = ton_year * COST_DB["price_ton_usd"]
    total_cost_yr  = total_cost_t * ton_year
    ebitda_yr      = revenue_yr - total_cost_yr
    ebitda_pct     = (ebitda_yr / max(revenue_yr, 1)) * 100
    payback_years  = total_capex / max(ebitda_yr, 1) if ebitda_yr > 0 else 99.0

    return {
        "energy_usd_t":   round(energy_cost_t, 4),
        "labor_usd_t":    round(labor_cost_t,  4),
        "maint_usd_t":    round(maint_cost_t,  4),
        "wear_usd_t":     round(wear_cost_t,   4),
        "total_usd_t":    round(total_cost_t,  3),
        "energy_kwh_t":   round(energy_kwh_t,  3),
        "ton_year_k":     round(ton_year / 1000, 1),
        "total_cost_yr_k":round(total_cost_yr / 1000, 0),
        "capex_m_usd":    round(total_capex / 1_000_000, 2),
        "maint_yr_k_usd": round(total_maint_yr / 1000, 0),
        "ebitda_yr_k":    round(ebitda_yr / 1000, 0),
        "ebitda_pct":     round(ebitda_pct, 1),
        "payback_years":  round(min(payback_years, 99.0), 1),
    }
